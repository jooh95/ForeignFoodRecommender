package com.example.joonoh.forfoodreco;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.net.ssl.HttpsURLConnection;

public class SlideAdapter extends PagerAdapter{

    Context context;
    LayoutInflater inflater;

    TextView food_category;
    TextView main_ingr1;
    TextView main_ingr2;
    TextView main_ingr3;
    TextView sub_ingr1;
    TextView food_name;
    TextView food_intro;
    ImageView food_image;
    Bitmap bitmap;

    String category, m_ingr1, m_ingr2,  m_ingr3, s_ingr1, imageURL,  name, intro;

    String f_name, c_name;

    Bitmap[] bitmaps, t_bitmaps;

    String[] categories, m_ingr1s, m_ingr2s,  m_ingr3s, s_ingr1s, imageURLs,  names, intros;
    String[] t_categories, t_m_ingr1s, t_m_ingr2s,  t_m_ingr3s, t_s_ingr1s, t_imageURLs,  t_names, t_intros;

    int length = 0;


    public int[] lst_images = {
        R.drawable.gyudong,
        R.drawable.buta,
        R.drawable.oggo,
    };

    private String convertStreamToString(InputStream is) {
        BufferedReader rd = new BufferedReader(new InputStreamReader(is), 4096);
        String line;
        StringBuilder sb =  new StringBuilder();
        try {
            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            rd.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String contentOfMyInputStream = sb.toString();
        return contentOfMyInputStream;
    }

    public SlideAdapter(Context context, String d_fname, String d_cname){

        this.context = context;
        this.f_name = d_fname;
        this.c_name = d_cname;

        Thread mThread = new Thread() {
            @Override
            public void run() {
                try {

                    Log.d("fname", f_name);
                    Log.d("cname", c_name);

                    String server_url = "https://f2vqdqpw58.execute-api.us-east-2.amazonaws.com/foodbeta2//food-recommendation?name=" + f_name + "&country=" + c_name;

                    URL dbServer = new URL(server_url);

                    Log.d("here", server_url);
                    // Create connection
                    HttpsURLConnection myConnection =  (HttpsURLConnection) dbServer.openConnection();
//                    myConnection.setRequestProperty("User-Agent", "my-rest-app-v0.1");
//                    myConnection.setRequestProperty("Accept", "application/vnd.github.v3+json");
                    Log.d("here", " after connection");

                    if (myConnection.getResponseCode() == 200) {
                        Log.d("here2", "2");
                        InputStream responseBody = myConnection.getInputStream();
                        InputStreamReader responseBodyReader = new InputStreamReader(responseBody, "UTF-8");

                        JsonReader jsonReader = new JsonReader(responseBodyReader);

                        String token = convertStreamToString(responseBody);

                        Log.d("rrrrr", token);


                        JSONObject json = new JSONObject(token);

                        length = json.getInt("length");


                        Log.d("length", Integer.toString(length));

                        t_bitmaps = new Bitmap[length];
                        t_categories = new String[length];
                        t_m_ingr1s = new String[length];
                        t_m_ingr2s = new String[length];
                        t_m_ingr3s = new String[length];
                        t_s_ingr1s = new String[length];
                        t_imageURLs = new String[length];
                        t_names = new String[length];
                        t_intros = new String[length];

                        Log.d("length1111", Integer.toString(length));


                        JSONArray jsonArray = json.getJSONArray("Food");


                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject json_data = jsonArray.getJSONObject(i);

                                t_categories[i] = json_data.getString("Category");;

                                //food_class.setText(value);

                                t_m_ingr1s[i] = json_data.getString("Main Ingredient1");;
                                t_m_ingr2s[i] = json_data.getString("Main Ingredient2");;
                                t_m_ingr3s[i] = json_data.getString("Main Ingredient3");
                                t_s_ingr1s[i] = json_data.getString("Sub Ingredient1");

                                t_names[i] = json_data.getString("Name");
                                t_intros[i] = json_data.getString("detail");
                                // Fetch the value as a String
                                imageURL = json_data.getString("ImageURL");

                                Log.d("image", imageURL);

                                URL url = new URL(imageURL);

                                // Web에서 이미지를 가져온 뒤
                                // ImageView에 지정할 Bitmap을 만든다
                                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                conn.setDoInput(true); // 서버로 부터 응답 수신
                                conn.connect();

                                InputStream is = conn.getInputStream(); // InputStream 값 가져오기
                                t_bitmaps[i] = BitmapFactory.decodeStream(is); // Bitmap으로 변환


                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        mThread.start();

        try{
            mThread.join();

            bitmaps = new Bitmap[length];
            categories = new String[length];
            m_ingr1s = new String[length];
            m_ingr2s = new String[length];
            m_ingr3s = new String[length];
            s_ingr1s = new String[length];
            imageURLs = new String[length];
            names = new String[length];
            intros = new String[length];

            for(int i = 0; i < length; i++){
                bitmaps[i] = t_bitmaps[i];
                categories[i] = t_categories[i];
                m_ingr1s[i] = t_m_ingr1s[i];
                m_ingr2s[i] = t_m_ingr2s[i];
                m_ingr3s[i] = t_m_ingr3s[i];
                s_ingr1s[i] = t_s_ingr1s[i];
                imageURLs[i] = t_imageURLs[i];
                names[i] = t_names[i];
                intros[i] = t_intros[i];
            }

        }catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getCount() {
        return length;
    }

    @Override
    public boolean isViewFromObject(View view, Object o) {
        return (view==(LinearLayout)o);
    }


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.slide_result, container, false);
        LinearLayout layoutslide = (LinearLayout) view.findViewById(R.id.slide_result);


        ImageView imgslides = (ImageView) view.findViewById(R.id.foodImage);
        imgslides.setImageBitmap(bitmaps[position]);

        food_category = (TextView) view.findViewById(R.id.food_class);
        main_ingr1 = (TextView) view.findViewById(R.id.main_ingr1);
        main_ingr2 = (TextView) view.findViewById(R.id.main_ingr2);
        main_ingr3 = (TextView) view.findViewById(R.id.main_ingr3);
        sub_ingr1 = (TextView) view.findViewById(R.id.sub_ingr1);
        food_name = (TextView) view.findViewById(R.id.food_name);
        food_intro = (TextView) view.findViewById(R.id.food_intro);

        food_category.setText(categories[position]);
        main_ingr1.setText(m_ingr1s[position]);
        main_ingr2.setText(m_ingr2s[position]);
        main_ingr3.setText(m_ingr3s[position]);
        sub_ingr1.setText(s_ingr1s[position]);
        food_name.setText(names[position]);
        food_intro.setText(intros[position]);


        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout)object);
    }
}


