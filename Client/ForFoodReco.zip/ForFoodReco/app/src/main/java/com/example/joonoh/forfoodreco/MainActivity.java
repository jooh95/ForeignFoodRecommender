package com.example.joonoh.forfoodreco;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner sp_start;
    ImageView flag_start;
    Spinner sp_end;
    ImageView flag_end;
    ArrayAdapter<String> sp_adapter;
    ImageButton search_btn;

    String startCountry = new String("");
    String destinationsCountry = new String("");

    String[] countries = {"선택", "한국", "중국", "일본"}; //서버에서 받아 오겠음.
    String[] food_list = { "牛丼", "牛肉薄切", "牛肉とねぎの中華まん", "牛肉と長芋の中華炒め", "牛肉とトマトのしょうゆ炒め"}; //자동완성 부분, 서버에서 받아 오겠음.

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.settings:
                Intent settings = new Intent(this, SettingsActivity.class);
                startActivity(settings);
                break;
            case R.id.help:
                Intent help = new Intent(this, HelpActivity.class);
                startActivity(help);
                break;

            case R.id.aboutUs:
                break;



        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar)findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        search_btn = (ImageButton)findViewById(R.id.search_btn);

        sp_start = (Spinner)findViewById(R.id.sp_start);
        flag_start = (ImageView)findViewById(R.id.flag_start);
        sp_end = (Spinner)findViewById(R.id.sp_end);
        flag_end = (ImageView)findViewById(R.id.flag_end);

        sp_adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item,countries);

        sp_start.setAdapter(sp_adapter);
        sp_end.setAdapter(sp_adapter);


        AutoCompleteTextView edit = (AutoCompleteTextView) findViewById(R.id.food_typed);

        edit.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, food_list));

        sp_start.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!destinationsCountry.equals("한국") && sp_start.getItemAtPosition(position).equals("한국")){
                    flag_start.setImageResource(R.drawable.korea);
                    startCountry = "한국";
                }
                else if(!destinationsCountry.equals("중국") && sp_start.getItemAtPosition(position).equals("중국")){
                    flag_start.setImageResource(R.drawable.china);
                    startCountry = "중국";
                }
                else if(!destinationsCountry.equals("일본") && sp_start.getItemAtPosition(position).equals("일본")){
                    flag_start.setImageResource(R.drawable.japan);
                    startCountry = "일본";
                }
                else if(sp_end.getItemAtPosition(position).equals("선택")){
                    flag_start.setImageResource(0);
                    startCountry = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp_end.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!startCountry.equals("한국") && sp_end.getItemAtPosition(position).equals("한국")){
                    destinationsCountry = "한국";
                    flag_end.setImageResource(R.drawable.korea);
                }
                else if(sp_end.getItemAtPosition(position).equals("중국")){
                    destinationsCountry = "중국";
                    flag_end.setImageResource(R.drawable.china);
                }
                else if(sp_end.getItemAtPosition(position).equals("일본")){
                    destinationsCountry = "일본";
                    flag_end.setImageResource(R.drawable.japan);
                }
                else if(sp_end.getItemAtPosition(position).equals("선택")){
                    destinationsCountry = "";
                    flag_end.setImageResource(0);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ResultActivity.class));
            }
        });


    }
}
